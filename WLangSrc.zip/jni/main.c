#include <jni.h>
#include <stdlib.h>
#include <stdint.h>

JNIEXPORT jint JNICALL Java_com_wither_wvm_NativeMethods_wvm(JNIEnv * env, jclass javaClass, jstring jstr){
		return 0;
};
JNIEXPORT jint JNICALL Java_com_wither_wvm_NativeMethods_setPath
  (JNIEnv * env, jclass javaClass, jstring jstr){
			return 0;
	};
