package com.wither.wvm;
import android.annotation.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import android.app.*;
public class FileViewAdapter extends ArrayAdapter<FileView> {
	Context cont;
	public FileViewAdapter(@NonNull Context context, int res, @NonNull List<FileView> objects){
		super(context, res, objects);
		cont = context;
	};
	public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
		FileView fv = (FileView) getItem(position);
		View view = LayoutInflater.from(getContext()).inflate(com.wither.wvm.R.layout.fileLayout, parent, false);
		//ViewGroup.LayoutParams params = view.getLayoutParams();
		//params.height = ((Activity)cont).findViewById(R.layout.activity_main).getHeight() / 10;
		//view.setLayoutParams(params);
		ImageView iv = view.findViewById(com.wither.wvm.R.id.fileIcon);
		TextView tv = view.findViewById(com.wither.wvm.R.id.fileName);
		iv.setImageResource(R.drawable.dir_icon);
		tv.setText(fv.name);
		return view;
	}
};
