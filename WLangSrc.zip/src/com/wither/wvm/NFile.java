package com.wither.wvm;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.io.*;
public class NFile {

	public static void fileCopy(String source, String dest) {
		try {
			int indexT = 0;
			for (int strIndex = 0; strIndex < dest.length(); strIndex++) {
				if (dest.charAt(strIndex) == '/') {
					indexT = strIndex;
				}
			}
			File destFile = new File(dest.substring(0, indexT));
			destFile.mkdirs();
			FileChannel sf = new FileInputStream(source).getChannel();
			FileChannel df = new FileOutputStream(dest).getChannel();
			df.transferFrom(sf, 0, sf.size());
			sf.close();
			df.close();

		} catch (Exception e) {
			System.out.println(e.toString());

		}
	}
}

