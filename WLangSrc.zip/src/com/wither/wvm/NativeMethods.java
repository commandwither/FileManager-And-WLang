package com.wither.wvm;

public class NativeMethods {
  public static native int wvm(String programPath);
  public static native int setPath(String path);
}