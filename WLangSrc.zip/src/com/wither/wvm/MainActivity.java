/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.wither.wvm;

import android.app.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import com.wither.wvm.*;
import android.*;
import android.content.pm.*;
import android.view.View.*;
import android.view.*;
import android.widget.AdapterView.*;

public class MainActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		String launcherPermissions[] = {Manifest.permission.MANAGE_EXTERNAL_STORAGE,
				Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
		for (int index = 0; index < launcherPermissions.length; index++) {
			if (!(checkSelfPermission(launcherPermissions[index]) == PackageManager.PERMISSION_GRANTED)) {
				requestPermissions(launcherPermissions, 0);
				break;
			}
		} ;
		PrintStream pStream = null;
		try {
			pStream = new PrintStream("/storage/emulated/0/WVM/log.txt");
		} catch (Exception e) {
		}
		System.setOut(pStream);
		TextView tv = findViewById(R.id.mainText);
		FileListView lv_L = new FileListView((ListView) findViewById(R.id.activityM_listView_left),
				Environment.getExternalStorageDirectory().getAbsolutePath());
		FileListView lv_R = new FileListView((ListView) findViewById(R.id.activityM_listView_right),
				Environment.getExternalStorageDirectory().getAbsolutePath());
		ListFiles(lv_L);
		ListFiles(lv_R);
	}

	private void ListFiles(final FileListView ListV) {
		File MDir = new File(ListV.getPath());
		File[] MFileList = MDir.listFiles();
		List<FileView> MFileInfo = new ArrayList<>();
		MFileInfo.add(new FileView("父目录"));
		for (int index = 0; index < MFileList.length; index++) {
			FileView temp = new FileView(MFileList[index].getName());
			MFileInfo.add(temp);
		}

		FileViewAdapter fva = new FileViewAdapter(this, R.layout.fileLayout, MFileInfo);
		ListV.getView().setAdapter(fva);
		ListV.getView().setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if(position == 0){
					
					return;
				}
				String temp = ListV.getPath() + "/" + ((TextView) view.findViewById(R.id.fileName)).getText();
				System.out.println(temp);
				if(new File(temp).isDirectory()){
					ListV.setPath(temp);
					ListFiles(ListV);
				}
			}
		});
	}
}
class FileListView {
	private String path;
	private ListView view;

	public FileListView(ListView lv, String ipath) {
		this.view = lv;
		this.path = ipath;

	}

	public String getPath() {
		return this.path;
	}
	public void setPath(String ipath) {
		this.path = ipath;
	}
	public ListView getView() {
		return this.view;
	}
	public void setView(ListView lv) {
		this.view = lv;
	}
}

