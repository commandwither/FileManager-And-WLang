package com.wither.wvm;
public class FileView {
	public String icon;
	public String name;
	public String description;
	public FileView (String name){
		this.name = name;
	}
}
